function sHandle = eSchmear(x, y, u, l, col)
% ESCHMEAR makes an error schmear on the current figure.
%
%	ESCHMEAR(X,Y,E) makes a +/- E schmear around the data
%	ESCHMEAR(X,Y,U,L) schmear goes from Y+U to Y-L
%   ESCHMEAR(X,Y,U,L, col) colors the schmear
%	SH = ESCHMEAR(...) returns a handle to the schmear patch object
%     
%   nota bene: you can use eSchmear to plot transparent lines by passing a
%   suitably small value for E
%
% see also: 
% 
% Lawrence K. Cormack

% history:
% 8/17/14  lkc Wrote it.

% arg handling 
if nargin < 3
    error('inputs = (x,y,e), (x,y,u,l), or (x,y,u,l,col)');
elseif nargin == 3
    l = u;
    col='r';
elseif nargin == 4
    col='r';
else
    % do nothing
end

% sort values by ascending x value so we can draw the patch
[x, inds] = sort(x);
y = y(inds);
% make able to handle vector and scaler errs gracefully
% u = u(inds);
% l = l(inds);

% make everybody row vectors
x = reshape(x, 1, numel(x));
y = reshape(y, 1, numel(y));
u = reshape(u, 1, numel(u));
l = reshape(l, 1, numel(l));

xe = [x, fliplr(x)];
ye = [y+abs(u) fliplr(y-abs(l))];

if ishold
    sHandle = fill(xe,ye,col);
else
    hold on;
    sHandle = fill(xe,ye,col);
    hold off;
end

set(sHandle, 'EdgeColor', 'none');
set(sHandle, 'FaceAlpha', 0.1);
