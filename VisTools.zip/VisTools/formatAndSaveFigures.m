% function sizeSave()
% resize, format, arrange objects in, and save all open figs

% this is the default figure size, [x y width height] - 0,0 is bottom left of screen
% ds = [440   378   560   420];

%% specify whatever now figure size you want here.
ns = [10   10   2.*560   2.*420];

%% get the handles for all open figures
figH = get(0, 'Children');
nFigs = numel(figH);

%% march through them and do your thing
for ii = 1:nFigs

    %% get current handles for code readability
    thisFig = figH(ii);  % 
    figure(thisFig);    
    thisAx = gca;       % ditto
    
    %% if figure isn't named, give it a numerical one.
    if ~exist(thisFig.Name, 'var')
        thisFig.Name = strcat("fig", num2str(ii));
    end
    
    %% example of how to rearrange objects to get a desired plotting order.
    %     ha = get(gca, 'Children');
    %     lh = findobj(ha, 'Type', 'Line');
    %     eh = findobj(ha, 'Type', 'ErrorBar');
    %     ph = findobj(ha, 'Type', 'Patch');
    %     front of this vector is front in plotting order
    %     in other words, objects are plotted back-to-front
    %     starting at the end of the handle vector
    
    %     ha = [lh; eh; ph];
    %     set(gca, 'Children', ha);   % re-plot in new order
    
    %% resize for export
    set(thisFig, 'Position', ns)
    
    %% set axis limits here if you wish
%     ylim([-0.04 0.14]);
    
    %% stick formatFigure() here iffn it ain't in yer plotting code
    formatFigure("my stupid x axis", "my stupid y axis", "my stupid title", 1, 0, 24, 28);
    
    %% save.  
    fname = thisFig.Name;
    % specify your export format here.  See the help for saveas() for options
    saveas(thisFig, fname, 'tiffn');
end

% close all

