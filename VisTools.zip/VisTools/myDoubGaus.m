function y = myDoubGaus(a, x)
% myDoubGab - a "double Guassian" in a form suitable for lsqcurvefit()
% where a double Gaussian is a Gaussian with
% different sigmas above and below the mean
% takes params in a
% 1 - the mean (and where the sds change)
% 2 - the lower or left sigma
% 3 - the upper or right sigma
% 4 - the height

lexi = x<=a(1);     % indeces of left and right sides
rexi = x>a(1);

lex = x(lexi);      % left and right x-axis values
rex = x(rexi);

% and compute the y values
y(lexi) = a(4).*exp(-(lex-a(1)).^2./(2.*a(2).^2));
y(rexi) = a(4).*exp(-(rex-a(1)).^2./(2.*a(3).^2));
