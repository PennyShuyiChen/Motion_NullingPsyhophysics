function y = myNakaRush(a, x)
% MYNAKARUSH
% Naka Rushton saturation response function
% y = myNakaRush(a, x);
% a(1) saturation maximum
% a(2) half-saturation point
% a(3) exponent
% a(4) offset along the x-axis


 ymax = a(1);
 x50 = a(2);
 n = a(3);
 offset = a(4);
 
 xo = x - offset;   % shift the x axis
 xo(xo<0) = 0;      % set any negative values to zero

y = ymax.*((xo.^n)./((xo.^n) + (x50.^n)));

