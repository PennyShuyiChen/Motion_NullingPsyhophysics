function ind = rc2ind(r, c, ncols)
% RC2IND - converts a (row, column) index into a linear index
%           in that left-to-right, top-to-bottomy way

ind = (r-1).*ncols + c;