% MouseTraceDemo4
%
% ___________________________________________________________________
% 
% Draw a curve with the mouse. Same as MouseTraceDemo, but asks
% Screen('Flip') to not clear the framebuffer after flip. This way,
% we don't need to redraw the whole mouse trace in each frame.
% Uses imaging pipeline via PsychImaging for optimal performance
% on modern hardware, as opposed to old style method shown in
% MouseTraceDemo2, which was appropriate before the year 2007.
% ___________________________________________________________________
%
% See also: PsychDemos, MouseTraceDemo, GetMouse.
%
% HISTORY
%                       
% 4/1/2013  mk       Derived from MouseTraceDemo2.
Screen('Preference', 'SkipSyncTests', 1);

try
    % Open up a window on the screen and clear it.
    whichScreen = max(Screen('Screens'));
    PsychImaging('PrepareConfiguration');
    PsychImaging('AddTask', 'General', 'UseVirtualFramebuffer');
    [theWindow,theRect] = PsychImaging('OpenWindow', whichScreen, 0);

    % Move the cursor to the center of the screen
    theX = theRect(RectRight)/2;
    theY = theRect(RectBottom)/2;
    SetMouse(theX,theY);

    % Wait for a click and hide the cursor
    Screen(theWindow,'TextSize',24);
    Screen(theWindow,'DrawText','move mouse to move edge',50,50,255);
    Screen('Flip', theWindow);
    while (1)
        [x,y,buttons] = GetMouse(theWindow);
        if buttons(1)
          break;
        end
    end
    Screen(theWindow,'DrawText','click  to finish',50,50,255);

    HideCursor;

    % Loop and track the mouse, drawing the edge
    [theX,theY] = GetMouse(theWindow);
    thePoints = [theX theY];
    Screen(theWindow,'FillRect',255,...
            [theRect(RectLeft), theY, theRect(RectRight), theRect(RectBottom)]);
    Screen('Flip', theWindow);
    while (1)
        [x,y,buttons] = GetMouse(theWindow);
        if buttons(1)
            break;
        end
        if (x ~= theX || y ~= theY)
            thePoints = [thePoints ; x y]; %#ok<AGROW>
            [numPoints, two]=size(thePoints);
            Screen(theWindow,'FillRect',255,...
                [theRect(RectLeft), theY, theRect(RectRight), theRect(RectBottom)]);
            Screen('Flip', theWindow);
            theX = x; theY = y;
        end
    end

    % Close up
    Screen(theWindow,'DrawText','Click mouse to finish',50,50,255);
    ShowCursor;
    Screen(theWindow,'Close');

catch
    Screen('CloseAll')
    ShowCursor;
    psychrethrow(psychlasterror);
end %try..catch..
