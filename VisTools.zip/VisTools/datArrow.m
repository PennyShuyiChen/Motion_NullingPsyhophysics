function ah = datArrow(xa, ya)
% DATARROW(xa, ya) draws an arrow annotation
% it is a wrapper for annotation('arrow'...) that allows
% you to specify the x and y pairs in data coordinates
% instead of stupid normalized figure coordinates, which
% is stupid

[xf, yf] = ds2nfu(xa, ya);

ah = annotation('arrow', xf, yf);