function [r,c] = ind2rc(ind, nCols)
% IND2RC -  converts a linear index into a (row,column) index.
%           Handy for use with subplot() in a loop.
% [r, c] = IND2RC(ind, nCols)

r = ceil(ind./nCols);
c = ind - (r-1).*nCols;