function y = mySigmoid(a, x)
% mySigmoid - a cumulative normal in a form suitable for lsqcurvefit()
% takes two params, a(1) is the mean, a(2) the sigma

y = 0.5 + 0.5.*normcdf(x, a(1), a(2));