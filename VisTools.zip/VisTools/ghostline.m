function ph = ghostline(x, y, w, a, c)
%GHOSTLINE plots a line or curve as a thin partially transparent polygon.  Handy for plotting bootstrap replicate fits on top 
%of one another to get visually-complelling error schmears
%   GHOSTLINE(X,Y) plots the graph of vector X vs. vector Y with default alpha and line width
%   
%   GHOSTLINE(X,Y, w, a, c) - specify width, al
%   
%   You should put some thought into how wide to make the line widths - you'll probably do a better job than my ad hoc default
%   algorithm will.  You might want to play with the alpha as well.
%
% NB:  ghostline() is used to make a transparent line or curve of constant width.  It is not meeant to make error schmears.  To
% do this, use errorschmear()
%
% 19-Mar-2018:  LKC wrote it

if ~exist('w', 'var') || isempty('w') w = 1; end        % 1 is a placeholder - what units to do this in?
if ~exist('a', 'var') || isempty('a') a = 0.1; end
if ~exist('c', 'var') || isempty('c') c = [1 0 0]; end

sx = size(x);
sy = size(y);
% allow y to be a matrix?
if min(sx) > 1 || min(sy) > 1
    error('x and y must be vectors');
end

% make both column vectors 
if (sx(1) == 1) x = x'; end
if (sy(1) == 1) y = y'; end

% make into polygon bounds
x = [x; flipud(x)];
y = [y + w; flipud(y) - w];

patch(x,y,c, 'FaceAlpha', a, 'EdgeColor', 'none');

