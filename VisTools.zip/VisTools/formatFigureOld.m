function formatFigure(labelX,labelY,titleName,bLogX,bLogY,fsLabels,fsTicks,axisHandle)

% formatFigure ?  automatically format figure with axis labels, title, log/linear scaling,
% and specified fontsize
%
% function formatFigure(labelX,labelY,titleName,bLogX,bLogY,fsLabels,fsTicks,axisHandle)
%
%   You must specify the x and y axis labels; the other arguments are optional.
%
%   example call: formatFigure('hello','world','log-log data plot', 1, 1, 14, 12)
%
%   which makes a log-log plot with x-axis label "hello" and y-axis label "world" with a
%   font size of 14, and sets the tick labels to a font size of 12.
%

% easy brut-force handling of optional arguments
% 
if ~exist('titleName','var')
    titleName = [];
end
if ~exist('bLogX','var') || isempty(bLogX)
    bLogX = 0;
end
if ~exist('bLogY','var') || isempty(bLogY)
    bLogY = 0;
end
if ~exist('fsLabels','var') || isempty(fsLabels)
    fsLabels = 20;
end
if ~exist('fsTicks','var')
    fsTicks = 16;
end
if ~exist('axisHandle','var') || isempty(axisHandle)
    axisHandle = gca;
end

% set sizes of axis labels and title
xlabel(labelX,'fontsize',fsLabels);
ylabel(labelY,'fontsize',fsLabels);
title(titleName,'fontsize',fsLabels);

% make axes logarithmic if requested
if bLogX == 1
    set(axisHandle,'xscale','log');
end
if bLogY == 1
    set(axisHandle,'yscale','log');
end

% set tick sizes
set(gca,'fontsize',fsTicks);

set(gcf,'color','w');   % make figure background white
box on                  % axes all around