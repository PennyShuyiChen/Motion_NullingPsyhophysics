% MoveEdgeWithMouse.m
%
% ___________________________________________________________________
% 
% Draw an edge with an input device.  For calibration.
% ___________________________________________________________________
%
%
% HISTORY
%                       
% 3/11/2014     lkc     Derived from MouseTraceDemo4.

Screen('Preference', 'SkipSyncTests', 1);

try
    % Open up a window on the screen and clear it.
    whichScreen = max(Screen('Screens'));
    PsychImaging('PrepareConfiguration');
    PsychImaging('AddTask', 'General', 'UseVirtualFramebuffer');
    [theWindow,theRect] = PsychImaging('OpenWindow', whichScreen, 0);

    % Move the cursor to the center of the screen
    theX = theRect(RectRight)/2;
    theY = theRect(RectBottom)/2;
    SetMouse(theX,theY);

    % Wait for a click and hide the cursor
    Screen(theWindow,'TextSize',24);
    Screen(theWindow,'DrawText','move mouse to move edge',50,50,255);
    Screen('Flip', theWindow);
    while (1)
        [x,y,buttons] = GetMouse(theWindow);
        if buttons(1)
          break;
        end
    end
    Screen(theWindow,'DrawText','click  to finish',50,50,255);

    pause(0.5);
    HideCursor;

    % Loop and track the mouse, drawing the edge
    
    f = matleap(1);
    xo = f.pointables(1).position(1);
    yo = f.pointables(1).position(2);
    
    theX = theRect(RectRight)/2;
    theY = theRect(RectBottom)/2;
    thePoints = [theX theY];
    Screen(theWindow,'FillRect',255,...
            [theRect(RectLeft), theY, theRect(RectRight), theRect(RectBottom)]);
    Screen('Flip', theWindow);
    while (1)
        [trashx,trashy,buttons] = GetMouse(theWindow);
        if buttons(1)
            break;
        end
        
        f = matleap(1);
        x = f.pointables(1).position(1);
        y = f.pointables(1).position(2);
        x = x-xo;
        y = -1*(y-yo);
         if (x ~= theX || y ~= theY)
            thePoints = [thePoints ; x y]; %#ok<AGROW>
            [numPoints, two]=size(thePoints);
            Screen(theWindow,'FillRect',255,...
                [theRect(RectLeft), theRect(RectBottom)/2 + theY, theRect(RectRight), theRect(RectBottom)]);
            Screen('Flip', theWindow);
            theX = x; theY = y;
        end
    end

    % Close up
    Screen(theWindow,'DrawText','Click mouse to finish',50,50,255);
    ShowCursor;
    Screen(theWindow,'Close');

catch
    Screen('CloseAll')
    ShowCursor;
    psychrethrow(psychlasterror);
end %try..catch..
